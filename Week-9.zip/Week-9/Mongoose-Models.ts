import express from "express";
import type { Request, Response } from "express";
import mongoose from "mongoose";

const app = express();
const PORT: number = 3000;

app.use(express.json());

const dbURI: string =
    "mongodb+srv://YOUR_USERNAME:YOUR_PASSWORD@cluster0.aj2kgiz.mongodb.net/LabDB?appName=Cluster0";

mongoose
    .connect(dbURI)
    .then(() => {
        console.log("Connected to MongoDB Atlas successfully!");
    })
    .catch((err: Error) => {
        console.error("Database connection error:", err);
    });

interface IStudent {
    name: string;
    rollNumber: number;
    course?: string;
    isActive?: boolean;
}

const studentSchema = new mongoose.Schema<IStudent>({
    name: {
        type: String,
        required: true
    },
    rollNumber: {
        type: Number,
        required: true,
        unique: true
    },
    course: {
        type: String
    },
    isActive: {
        type: Boolean,
        default: true
    }
});

const Student = mongoose.model<IStudent>("Student", studentSchema);

// CREATE
app.post(
    "/students",
    async (req: Request, res: Response): Promise<void> => {
        try {
            const newStudent = new Student(req.body);
            const savedStudent = await newStudent.save();

            res.status(201).json(savedStudent);
        } catch (error) {
            const err = error as Error;

            res.status(400).json({
                message: "Error saving student",
                error: err.message
            });
        }
    }
);

// READ
app.get(
    "/students",
    async (req: Request, res: Response): Promise<void> => {
        try {
            const students = await Student.find();

            res.status(200).json(students);
        } catch (error) {
            const err = error as Error;

            res.status(500).json({
                message: "Error fetching students",
                error: err.message
            });
        }
    }
);

// UPDATE
app.put(
    "/students/:id",
    async (
        req: Request<{ id: string }>,
        res: Response
    ): Promise<void> => {
        try {
            const updatedStudent =
                await Student.findByIdAndUpdate(
                    req.params.id,
                    req.body,
                    { new: true }
                );

            if (!updatedStudent) {
                res.status(404).json({
                    message: "Student not found"
                });
                return;
            }

            res.status(200).json(updatedStudent);
        } catch (error) {
            const err = error as Error;

            res.status(400).json({
                message: "Error updating student",
                error: err.message
            });
        }
    }
);

// DELETE
app.delete(
    "/students/:id",
    async (
        req: Request<{ id: string }>,
        res: Response
    ): Promise<void> => {
        try {
            const deletedStudent =
                await Student.findByIdAndDelete(req.params.id);

            if (!deletedStudent) {
                res.status(404).json({
                    message: "Student not found"
                });
                return;
            }

            res.status(200).json({
                message: "Student record deleted successfully"
            });
        } catch (error) {
            const err = error as Error;

            res.status(500).json({
                message: "Error deleting student",
                error: err.message
            });
        }
    }
);

app.listen(PORT, (): void => {
    console.log(
        `Server is running at http://localhost:${PORT}`
    );

    console.log("Ready for CRUD operations testing.");
});
